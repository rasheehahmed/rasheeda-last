public class DoublyLinkedList<E>{
    private Node<E>header;
    private Node<E>trailer;
    private int size=0;
    public DoublyLinkedList()
    {
        header=new Node<>(null,null,null);
        trailer= new Node<>(null,header,null);
        header.setNext(trailer);
    }



    //public int size()
    //{return size;}
    public boolean isEmpty(){
        return size==0;}
    public E first()
    {if (isEmpty())return null;
        return header.getNext().getElement();
    }
    public E last()
    {if (isEmpty())return null;
        return trailer.getPrev().getElement();
    }
    private void addBetween(E e,Node<E>p,Node<E>n)
    {
        Node<E>newest= new Node<>(e,p,n);
        p.setNext(newest);
        n.setPrev(newest);
        size++;}
    public void addFirst(E ee)
    {
        addBetween(ee,header,header.next);}
    public void addLast(E ee)
    {
        addBetween(ee,trailer.prev,trailer);
    }
    private E remove(Node<E>x)
    {Node<E>p=x.prev;
        Node<E>n=x.next;
        p.setNext(n);
        n.setPrev(p);
        size--;
        return x.element;}
    public E removeFirst()
    {if (isEmpty())return null;
        return remove(header.next);}
    public E removeLast()
    {if (isEmpty())return null;
        return remove(trailer.prev);}


    //Describe a method for finding the middle node of a doubly linked list with header and trailer sentinels by “link hopping,” and without relying on explicit knowledge of the size of the list. In the case of an even number of nodes, report the node slightly left of center as the “middle
    public Node<E> findMiddleNode() {
        if (isEmpty()) {
            return null;
        }

        Node<E> s = header.getNext();
        Node<E> f = header.getNext();

        while (f != trailer && f.getNext() != trailer) {
            s = s.getNext();
            f = f.getNext().getNext();
        }

        return s;
    }

    //2.	Give an implementation of the size( ) method for the DoublyLinkedList class, assuming that we did not maintain size as an instance variable
    public int size() {
        int count = 0;
        Node<E> nodes = header.getNext();

        while (nodes != trailer) {
            count++;
            nodes = nodes.getNext();
        }

        return count;
    }

    //3.	Implement the equals( ) method for the DoublyLinkedList class.
    public boolean equals(DoublyLinkedList<E> otherList) {
        if (size() != otherList.size()) {
            return false;
        }

        Node<E> n1 = header.getNext();
        Node<E> n2 = otherList.header.getNext();

        while (n1 != trailer) {
            if (!n1.getElement().equals(n2.getElement())) {
                return false;
            }

            n1 = n1.getNext();
            n2 = n2.getNext();
        }

        return true;
    }

    //4.Give an algorithm for concatenating two doubly linked lists L and M, with header and trailer sentinel nodes, into a single list L′
    public void reverse() {
        if (isEmpty()) {
            return;
        }

        Node<E> current = header.getNext();
        Node<E> temp;

        while (current != trailer) {
            temp = current.getNext();
            current.setNext(current.getPrev());
            current.setPrev(temp);
            current = temp;
        }

        temp = header;
        header = trailer;
        trailer = temp;
    }

    //5.Our implementation of a doubly linked list relies on two sentinel nodes, header and trailer, but a single sentinel node that guards both ends of the list should suffice. Reimplement the DoublyLinkedList class using only one sentinel node
    public void removeDuplicates() {
        if (isEmpty()) {
            return;
        }

        Node<E> c = header.getNext();

        while (c.getNext() != trailer) {
            Node<E> r = c.getNext();

            while (r != trailer) {
                if (c.getElement().equals(r.getElement())) {
                    Node<E> prev = r.getPrev();
                    Node<E> next = r.getNext();

                    prev.setNext(next);
                    next.setPrev(prev);
                }

                r = r.getNext();
            }

            c = c.getNext();
        }
    }

    //6.Implement a circular version of a doubly linked list, without any sentinels, that supports all the public behaviors of the original as well as two new update methods, rotate( ) and rotateBackward
    public void rotate() {
        if (isEmpty() || size() == 1) {
            return;
        }

        Node<E> lastNode = trailer.getPrev();
        Node<E> firstNode = header.getNext();

        lastNode.setNext(firstNode);
        firstNode.setPrev(lastNode);

        header.setNext(firstNode.getNext());
        firstNode.getNext().setPrev(header);

        firstNode.setNext(trailer);
        trailer.setPrev(firstNode);
    }

    //7.Implement the clone( ) method for the DoublyLinkedList class
    public DoublyLinkedList<E> clone() {
        DoublyLinkedList<E> newList = new DoublyLinkedList<>();

        Node<E> c = header.getNext();

        while (c != trailer) {
            newList.addLast(c.getElement());
            c = c.getNext();
        }

        return newList;
    }

    private static class Node<E>
    {
        E element;
        Node<E>prev;
        Node<E>next;
        public Node(E element, Node<E> prev, Node<E> next) {
            this.element = element;
            this.prev = prev;
            this.next = next;
        }

        public E getElement() {
            return element;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getPrev() {
            return prev;
        }

        public void setPrev(Node<E> prev) {
            this.prev = prev;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }
    }
}

