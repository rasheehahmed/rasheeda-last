import java.util.LinkedList;

public class LinkedStack <E> implements Stack<E>{
LinkedList<E>l= new LinkedList<>();

    @Override
    public int size() {
        return l.size();
    }

    @Override
    public boolean isEmpty() {
        return l.isEmpty();
    }

    @Override
    public void push(E e) {
l.addLast(e);
    }

    @Override
    public E pop() {
        return l.removeLast();
    }

    @Override
    public E top() {
        return l.getLast();
    }

    //1.Implement a method with signature transfer(S, T) that transfers all elements from stack S onto stack T, so that the element that starts at the top of S is the first to be inserted onto T, and the element at the bottom of S ends up at the top of T
    public static <E> void transfer(LinkedStack<E> S, LinkedStack<E> T) {
        while (!S.isEmpty()) {
            E element = S.pop();
            T.push(element);
        }
    }
    //2.	Give a recursive method for removing all the elements from a stack
    public static <E> void removeAll(LinkedStack<E> stack) {
        while (!stack.isEmpty()) {
            stack.pop();
        }
    }

    //3.	Postfix notation is an unambiguous way of writing an arithmetic expression without parentheses. It is defined so that if “(exp1)op(exp2)” is a normal fully parenthesized expression whose operation is op, the pos Implement a method with signature transfer(S, T) that transfers all elements from stack S onto stack T, so that the element that starts at the top of S is the first to be inserted onto T, and the element at the bottom of S ends up at the top of T tfix version of this is “pexp1 pexp2 op”, where pexp1 is the postfix version of exp1 and pexp2 is the postfix version of exp2. The postfix version of a single number or variable is just that number or variable. So, for example, the postfix version of “((5 + 2) ∗ (8 − 3))/4” is “5 2 + 8 3 − ∗ 4 /”. Describe a nonrecursive way of evaluating an expression in postfix notation
    /*أنشئ ستاك فارغ.
قراءة التعبير من اليسار إلى اليمين.
لكل عنصر في التعبير:
إذا كان العنصر رقمًا (لا يعتبر عملية):
ضع العنصر في الستاك.
إذا كان العنصر عملية:
قم بإزالة عدد العناصر المطلوب من الستاك وقم بتنفيذ العملية عليها.
ضع النتيجة في الستاك.
في نهاية التعبير، القيمة النهائية ستكون العنصر الوحيد في الستاك.
استخرج العنصر من الستاك واستخدمه كنتيجة للتعبير.

     */

    //4.	Implement the clone( ) method for the ArrayStack class
    public LinkedStack<E> clone() {
        LinkedStack<E> clonedStack = new LinkedStack<>();
        LinkedList<E> temp = new LinkedList<>(l);
        while (!temp.isEmpty()) {
            clonedStack.push(temp.removeLast());
        }
        return clonedStack;
    }

}
