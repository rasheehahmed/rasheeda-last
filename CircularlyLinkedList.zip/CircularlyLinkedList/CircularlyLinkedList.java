
import org.w3c.dom.Node;

public class CircularlyLinkedList<E> {
    private Node<E>tail=null;
    private int size=0;
    public CircularlyLinkedList(){}
    public boolean isEmpty(){
        return size==0;}
    public int size(){
        return size;}

    public E first(){
        if (isEmpty())
            return null;
        return tail.next.element;

    }
    public E last(){
        if (isEmpty())
            return null;
        return tail.element;

    }
    public void rotate(){
        if (tail!=null)
            tail=tail.next;
    }
    //public void addFirst(E elem){
        //if (size==0)
       // {tail=new Node<>(elem,null);
          //  tail.next=tail;
       // }
       //// else {
        //    Node <E>newest=new Node<>(elem,tail.next);
        //    tail.next=newest;
       // }
       // size++;
   // }
    public void addLast(E ppp){
        addFirst(ppp);
        tail=tail.next;
    }
    public E removeFirst(){
        if (isEmpty())return null;
        Node<E> n=tail.next;
        if (n==tail)tail=null;
        else tail.next=n.next;
        size--;
        return n.element;

    }

//Consider the implementation of CircularlyLinkedList.addFirst, in Code Fragment 3.16. The else body at lines 39 and 40 of that method relies on a locally declared variable, newest. Redesign that clause to avoid use of any local variable
public void addFirst(E elem) {
    if (size == 0) {
        tail = new Node<>(elem, null);
        tail.next = tail;
    } else {
        tail.next = new Node<>(elem, tail.next);
        tail = tail.next;
    }
    size++;
}

//2.Give an implementation of the size( ) method for the CircularlyLinkedList class, assuming that we did not maintain size as an instance variable
public int size1() {
    if (isEmpty()) {
        return 0;
    }
    int count = 1;
    Node<E> current = tail.next;
    while (current != tail) {
        count++;
        current = current.next;
    }
    return count;
}


//3.Implement the equals( ) method for the CircularlyLinkedList class, assuming that two lists are equal if they have the same sequence of elements, with corresponding elements currently at the front of the list
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }
    CircularlyLinkedList<?> other = (CircularlyLinkedList<?>) obj;
    if (size() != other.size()) {
        return false;
    }
    Node<E> current = tail.next;
    Node<?> otherCurrent = other.tail.next;
    while (current != tail) {
        if (!current.element.equals(otherCurrent.element)) {
            return false;
        }
        current = current.next;
        otherCurrent = otherCurrent.next;
    }
    return tail.element.equals(other.tail.element);
}

//4.Suppose you are given two circularly linked lists, L and M. Describe an algorithm for telling if L and M store the same sequence of elements (but perhaps with different starting points).
public static <E> boolean sameSequence(CircularlyLinkedList<E> list1, CircularlyLinkedList<E> list2) {
    if (list1.size() != list2.size()) {
        return false;
    }
    if (list1.isEmpty() && list2.isEmpty()) {
        return true;
    }
    Node<E> current1 = list1.tail.next;
    Node<E> current2 = list2.tail.next;
    while (current1 != list1.tail) {
        if (current1.element.equals(current2.element)) {
            Node<E> temp = current2.next;
            while (temp != current2) {
                if (temp.element.equals(current1.next.element)) {
                    break;
                }
                temp = temp.next;
            }
            if (temp == current2) {
                return false;
            }
        }
        current1 = current1.next;
    }
    return true;
}

//5.Given a circularly linked list L containing an even number of nodes, describe how to split L into two circularly linked lists of half the size
public void splitList() {
    if (size <= 1) {
        return;
    }
    int mid = size / 2;
    Node<E> current = tail.next;
    Node<E> prev = tail;

    // تحرك للعقدة الوسطية
    for (int i = 0; i < mid; i++) {
        prev = current;
        current = current.next;
    }

    // قم بتعيين العقدة الأخيرة للقائمة الأولى (L1)
    Node<E> newTail = prev;
    // قم بتعيين العقدة الأولى للقائمة الثانية (L2)
    Node<E> newHead = current;

    // جعل القائمة الأولى (L1) دائرية
    newTail.next = tail.next;
    tail.next = newHead;

    // جعل القائمة الثانية (L2) دائرية
    tail = newTail;
}

//6.Implement the clone( ) method for the CircularlyLinkedList class.
public CircularlyLinkedList<E> clone() {
    try {
        CircularlyLinkedList<E> clonedList = (CircularlyLinkedList<E>) super.clone();
        if (size > 0) {
            clonedList.tail = new Node<>(tail.element, null);
            Node<E> current = tail.next;
            Node<E> clonedCurrent = clonedList.tail;

            while (current != tail) {
                Node<E> newNode = new Node<>(current.element, null);
                clonedCurrent.next = newNode;
                current = current.next;
                clonedCurrent = clonedCurrent.next;
            }

            clonedCurrent.next = clonedList.tail;
        }

        return clonedList;
    } catch (CloneNotSupportedException e) {
        throw new RuntimeException(e.getMessage());
    }
}


    private static class Node<E>
    {
        E element;
        Node<E>next;

        public Node(E element, Node<E> next) {
            this.element = element;
            this.next = next;
        }

    }

}
