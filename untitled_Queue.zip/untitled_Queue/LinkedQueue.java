import java.util.LinkedList;

public class LinkedQueue <E> implements Queue<E>{
    LinkedList<E>l= new LinkedList<>();
    @Override
    public int size() {
        return l.size();
    }

    @Override
    public boolean isEmpty() {
        return l.isEmpty();
    }

    @Override
    public void enqueue(E e) {
l.addFirst(e);
    }

    @Override
    public E dequeue() {
        return l.removeLast();
    }

    @Override
    public E first() {
        return l.getLast();
    }
    //rotate( )
    public void rotate() {
        if (l.size() >= 2) {
            E element = l.removeLast();
            l.addFirst(element);
        }
    }

    //2.Implement the clone( ) method for the ArrayQueue class
    @Override
    public LinkedQueue<E> clone() throws CloneNotSupportedException {
        LinkedQueue<E> clonedQueue = new LinkedQueue<>();
        for (E element : l) {
            clonedQueue.enqueue(element);
        }
        return clonedQueue;
    }

    //3.Implement a method with signature concatenate(LinkedQueue Q2) for the LinkedQueue class that takes all elements of Q2 and appends them to the end of the original queue. The operation should run in O(1) time and should result in Q2 being an empty queue
    public void concatenate(LinkedQueue<E> clone) {
        if (clone.isEmpty()) {
            return;
        }

        if (this.isEmpty()) {
            l = clone.l;
        } else {
            Node<E> lastNode = l.getLastNode();
            lastNode.next = clone.l.getFirstNode();
        }

        l.size += clone.size();
        clone.clear();
    }

    //4.Use a queue to solve the Josephus Problem
    public static int josephus(int n, int k) {
        LinkedQueue<Integer> queue = new LinkedQueue<>();
        for (int i = 1; i <= n; i++) {
            queue.enqueue(i);
        }

        while (queue.size() > 1) {
            for (int i = 0; i < k - 1; i++) {
                queue.enqueue(queue.dequeue());
            }
            queue.dequeue();
        }

        return queue.first();
    }

    //5.Use a queue to simulate Round Robin Scheduling
    public static void roundRobinScheduling(int[] processes, int[] burstTimes, int timeQuantum) {
        LinkedQueue<Integer> queue = new LinkedQueue<>();
        int n = processes.length;
        int[] remainingTimes = new int[n];

        for (int i = 0; i < n; i++) {
            queue.enqueue(processes[i]);
            remainingTimes[i] = burstTimes[i];
        }

        int currentTime = 0;

        while (!queue.isEmpty()) {
            int currentProcess = queue.dequeue();
            int executionTime = Math.min(timeQuantum, remainingTimes[currentProcess]);

            remainingTimes[currentProcess] -= executionTime;
            currentTime += executionTime;

            if (remainingTimes[currentProcess] > 0) {
                queue.enqueue(currentProcess);
            } else {
                System.out.println("Process " + currentProcess + " executed at time " + currentTime);
            }
        }
    }
}
